exports.router = router => {
  require('./stats.route')(router);
};
